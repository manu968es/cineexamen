/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function mostrarButaca(but){
    document.getElementById('dat2').value=but.datosb.value;
    document.getElementById('dat').style.display="block";
}
function ocultar(){
    document.getElementById('dat').style.display="none";
}